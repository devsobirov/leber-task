<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sobirov O. - Leber test assignment</title>
</head>
<body>
    <h2>Собиров Отабек Кахраман угли, 30 л</h2>
    <h4><a target='_blank' href='https://hh.ru/resume/bf6d0024ff091d71520039ed1f434e4a70664b'>Резюме - Fullstack developer (PHP, Laravel)</a>
    <h4><a href='mailto:devsobirov@gmail.com'>Email - devsobirov@gmail.com</a>
    <h4><a href='mailto:devsobirov@gmail.com'>Requirements: PHP ^8.0</a>
    <br>
    <br>
    <p><a href="./task1">Задание 1: PHP </a></p>
    <p><a href="./task2">Задание 2: PhpSpreadsheet</a></p>
    <p><a href="./task3">Задание 3: Watermark</a></p>
    <p><a href="./task4">Задание 4: CLI</a></p>
    <p><a href="./task5">Задание 5: Laravel</a></p>
</body>
</html>